/*global define*/
define( [], function () {
    'use strict';
    return {
          qListObjectDef: {
            qShowAlternatives: true,
            qFrequencyMode: "V",
            selectionMode : "CONFIRM",
            qInitialDataFetch: [{
              qWidth: 2,
              qHeight: 50
            }]
          }
    };
} );
